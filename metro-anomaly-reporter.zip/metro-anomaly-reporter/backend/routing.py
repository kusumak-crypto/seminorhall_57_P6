STATION_PREFIX_ROUTING = {
    "EA": {"zone": "East", "control_room": "East Control Room"},
    "WE": {"zone": "West", "control_room": "West Control Room"},
    "CE": {"zone": "Central", "control_room": "Central Control Room"},
}


def route_report(station_code: str, category: str) -> dict:
    if category == "Medical":
        return {
            "zone": "Central",
            "destination": "Central Emergency Line",
            "is_emergency_escalation": True,
        }

    prefix = station_code[:2]
    route = STATION_PREFIX_ROUTING.get(prefix)
    if route is None:
        return {
            "zone": "Unknown",
            "destination": "Central Fallback / Correction Queue",
            "is_emergency_escalation": False,
            "fallback": True,
        }

    return {
        "zone": route["zone"],
        "destination": route["control_room"],
        "is_emergency_escalation": False,
        "fallback": False,
    }
