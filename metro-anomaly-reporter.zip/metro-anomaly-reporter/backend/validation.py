import re

STATION_REGEX = re.compile(r"[A-Z]{2}[0-9]{3}\Z")
ANOMALY_REGEX = re.compile(r"A[0-9]{2}\Z")


def dfa_station(code: str) -> bool:
    """Explicit DFA simulation for AA999: q0 -> q1 -> q2 -> q3 -> q4 -> q5."""
    if not isinstance(code, str):
        return False
    state = 0
    for ch in code:
        if state in (0, 1) and "A" <= ch <= "Z":
            state += 1
        elif state in (2, 3, 4) and "0" <= ch <= "9":
            state += 1
        else:
            return False
    return state == 5


def dfa_anomaly(code: str) -> bool:
    """Explicit DFA simulation for A99: q0 -> q1 -> q2 -> q3."""
    if not isinstance(code, str):
        return False
    transitions = {
        0: lambda c: c == "A",
        1: lambda c: "0" <= c <= "9",
        2: lambda c: "0" <= c <= "9",
    }
    state = 0
    for ch in code:
        if state not in transitions or not transitions[state](ch):
            return False
        state += 1
    return state == 3


def regex_station(code: str) -> bool:
    return isinstance(code, str) and bool(STATION_REGEX.fullmatch(code))


def regex_anomaly(code: str) -> bool:
    return isinstance(code, str) and bool(ANOMALY_REGEX.fullmatch(code))


def validate_identifiers(station_code: str, anomaly_code: str) -> dict:
    station_dfa = dfa_station(station_code)
    station_regex_result = regex_station(station_code)
    anomaly_dfa = dfa_anomaly(anomaly_code)
    anomaly_regex_result = regex_anomaly(anomaly_code)

    messages = []
    if not station_dfa:
        messages.append("Station code must contain exactly 2 uppercase letters followed by 3 digits (example: EA123).")
    if not anomaly_dfa:
        messages.append("Anomaly code must contain A followed by exactly 2 digits (example: A02).")

    return {
        "valid": station_dfa and anomaly_dfa,
        "station_dfa": station_dfa,
        "station_regex": station_regex_result,
        "anomaly_dfa": anomaly_dfa,
        "anomaly_regex": anomaly_regex_result,
        "dfa_regex_agree": station_dfa == station_regex_result and anomaly_dfa == anomaly_regex_result,
        "messages": messages,
    }
