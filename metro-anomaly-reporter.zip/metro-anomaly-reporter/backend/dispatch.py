import heapq


def priority_rank(priority: str) -> int:
    return {"Critical": 0, "High": 1, "Normal": 2}.get(priority, 3)


def order_reports(reports):
    """Stable priority queue: priority first, then creation timestamp, then report ID."""
    heap = []
    for report in reports:
        heapq.heappush(
            heap,
            (
                priority_rank(report["priority"]),
                report["created_at"],
                report["report_id"],
                report,
            ),
        )
    ordered = []
    while heap:
        ordered.append(heapq.heappop(heap)[3])
    return ordered


def choose_handler(handlers, zone):
    """Greedy choice: eligible handler with lowest current workload."""
    eligible = [
        h for h in handlers
        if h["zone"] == zone
        and h["available"]
        and h["current_workload"] < h["capacity"]
    ]
    if not eligible:
        return None
    return min(eligible, key=lambda h: (h["current_workload"], h["handler_id"]))
