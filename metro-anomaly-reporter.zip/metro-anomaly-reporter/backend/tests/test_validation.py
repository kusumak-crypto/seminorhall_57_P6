import unittest
from validation import dfa_station, dfa_anomaly, regex_station, regex_anomaly, validate_identifiers


class ValidationTests(unittest.TestCase):
    def test_station_valid(self):
        for value in ["EA123", "WE456", "CE789"]:
            self.assertTrue(dfa_station(value))
            self.assertTrue(regex_station(value))

    def test_station_invalid(self):
        for value in ["E123", "EAA123", "EA12", "ea123", "EA12A", "EA1234", ""]:
            self.assertFalse(dfa_station(value))
            self.assertFalse(regex_station(value))

    def test_anomaly_valid(self):
        self.assertTrue(dfa_anomaly("A01"))
        self.assertTrue(regex_anomaly("A01"))

    def test_anomaly_invalid(self):
        for value in ["A1", "B01", "A001", "a01", "A0A", ""]:
            self.assertFalse(dfa_anomaly(value))
            self.assertFalse(regex_anomaly(value))

    def test_dfa_regex_agree(self):
        for station in ["EA123", "E123", "ea123", "WE456"]:
            for anomaly in ["A01", "A2", "B01", "A05"]:
                result = validate_identifiers(station, anomaly)
                self.assertTrue(result["dfa_regex_agree"])


if __name__ == "__main__":
    unittest.main()
