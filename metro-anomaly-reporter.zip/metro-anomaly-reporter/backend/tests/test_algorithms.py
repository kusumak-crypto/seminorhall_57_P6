import unittest
from classification import classify_report
from routing import route_report
from dispatch import order_reports, choose_handler


class AlgorithmTests(unittest.TestCase):
    def test_all_five_categories(self):
        cases = {
            ("A01", "Smoke detected"): "Safety",
            ("A02", "Escalator failure"): "Technical",
            ("A03", "Platform overcrowding"): "Crowd",
            ("A04", "Garbage on platform"): "Cleanliness",
            ("A05", "Passenger unconscious"): "Medical",
        }
        for (code, description), expected in cases.items():
            self.assertEqual(classify_report(code, description)["category"], expected)

    def test_medical_override(self):
        result = classify_report("A02", "Passenger unconscious near escalator")
        self.assertEqual(result["category"], "Medical")

    def test_unknown_code(self):
        self.assertFalse(classify_report("A99", "Something happened")["ok"])

    def test_medical_central_route(self):
        route = route_report("EA123", "Medical")
        self.assertEqual(route["destination"], "Central Emergency Line")

    def test_unknown_prefix_fallback(self):
        route = route_report("XX123", "Technical")
        self.assertTrue(route["fallback"])

    def test_priority_queue(self):
        reports = [
            {"report_id": "R1", "priority": "Normal", "created_at": "2026-01-01T00:00:00"},
            {"report_id": "R2", "priority": "Critical", "created_at": "2026-01-01T00:01:00"},
            {"report_id": "R3", "priority": "High", "created_at": "2026-01-01T00:02:00"},
        ]
        self.assertEqual([r["report_id"] for r in order_reports(reports)], ["R2", "R3", "R1"])

    def test_greedy_handler(self):
        handlers = [
            {"handler_id": "H1", "zone": "East", "available": 1, "current_workload": 3, "capacity": 5},
            {"handler_id": "H2", "zone": "East", "available": 1, "current_workload": 1, "capacity": 4},
            {"handler_id": "H3", "zone": "East", "available": 0, "current_workload": 0, "capacity": 4},
        ]
        self.assertEqual(choose_handler(handlers, "East")["handler_id"], "H2")

    def test_no_eligible_handler(self):
        handlers = [
            {"handler_id": "H1", "zone": "East", "available": 0, "current_workload": 0, "capacity": 5},
            {"handler_id": "H2", "zone": "East", "available": 1, "current_workload": 5, "capacity": 5},
        ]
        self.assertIsNone(choose_handler(handlers, "East"))

    def test_priority_tie_uses_timestamp(self):
        reports = [
            {"report_id": "R-later", "priority": "Critical", "created_at": "2026-01-01T10:02:00"},
            {"report_id": "R-earlier", "priority": "Critical", "created_at": "2026-01-01T10:01:00"},
        ]
        self.assertEqual([r["report_id"] for r in order_reports(reports)], ["R-earlier", "R-later"])

    def test_anomaly_code_mapping_without_keywords(self):
        result = classify_report("A04", "Platform issue reported by staff")
        self.assertEqual(result["category"], "Cleanliness")


if __name__ == "__main__":
    unittest.main()
