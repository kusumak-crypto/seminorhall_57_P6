import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).with_name("metro.db")


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    with get_connection() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS handlers (
            handler_id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            zone TEXT NOT NULL,
            capacity INTEGER NOT NULL CHECK(capacity >= 0),
            current_workload INTEGER NOT NULL DEFAULT 0 CHECK(current_workload >= 0),
            available INTEGER NOT NULL DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS reports (
            report_id TEXT PRIMARY KEY,
            reporter_name TEXT NOT NULL,
            station_code TEXT NOT NULL,
            anomaly_code TEXT NOT NULL,
            description TEXT NOT NULL,
            category TEXT NOT NULL,
            priority TEXT NOT NULL,
            zone TEXT NOT NULL,
            destination TEXT NOT NULL,
            handler_id TEXT,
            status TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            validation_json TEXT NOT NULL,
            dispatch_note TEXT,
            FOREIGN KEY(handler_id) REFERENCES handlers(handler_id)
        );

        CREATE TABLE IF NOT EXISTS status_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            report_id TEXT NOT NULL,
            old_status TEXT,
            new_status TEXT NOT NULL,
            changed_by TEXT NOT NULL,
            changed_at TEXT NOT NULL,
            note TEXT,
            FOREIGN KEY(report_id) REFERENCES reports(report_id)
        );

        CREATE INDEX IF NOT EXISTS idx_reports_status ON reports(status);
        CREATE INDEX IF NOT EXISTS idx_reports_zone ON reports(zone);
        CREATE INDEX IF NOT EXISTS idx_reports_category ON reports(category);
        """)

        count = conn.execute("SELECT COUNT(*) FROM handlers").fetchone()[0]
        if count == 0:
            demo_handlers = [
                ("H01", "Asha", "East", 5, 2, 1),
                ("H02", "Ravi", "East", 3, 3, 1),
                ("H03", "Meera", "West", 4, 1, 1),
                ("H04", "Arun", "Central", 5, 2, 1),
                ("H05", "Nisha", "Central", 3, 0, 1),
            ]
            conn.executemany(
                """INSERT INTO handlers
                (handler_id, name, zone, capacity, current_workload, available)
                VALUES (?, ?, ?, ?, ?, ?)""",
                demo_handlers,
            )


def row_to_dict(row):
    return dict(row) if row is not None else None
