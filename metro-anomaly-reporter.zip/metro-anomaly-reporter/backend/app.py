from flask import Flask, request, jsonify
from flask_cors import CORS
from datetime import datetime, timezone
import json
import uuid

from database import init_db, get_connection
from validation import validate_identifiers
from classification import classify_report
from routing import route_report
from dispatch import choose_handler, order_reports

app = Flask(__name__)
CORS(app)
init_db()

VALID_STATUSES = {"Pending", "Assigned", "In Progress", "Resolved"}


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def generate_report_id():
    return "MAR-" + uuid.uuid4().hex[:8].upper()


def dispatch_pending_reports(conn):
    rows = conn.execute(
        "SELECT * FROM reports WHERE status = 'Pending' ORDER BY created_at, report_id"
    ).fetchall()
    reports = order_reports([dict(row) for row in rows])
    decisions = []

    for report in reports:
        # Medical reports are always routed to the central emergency line.
        target_zone = "Central" if report["category"] == "Medical" else report["zone"]
        handlers = [
            dict(row) for row in conn.execute(
                "SELECT * FROM handlers WHERE zone = ? ORDER BY handler_id",
                (target_zone,),
            ).fetchall()
        ]
        handler = choose_handler(handlers, target_zone)

        if handler:
            conn.execute(
                "UPDATE handlers SET current_workload = current_workload + 1 WHERE handler_id = ?",
                (handler["handler_id"],),
            )
            conn.execute(
                """UPDATE reports SET handler_id = ?, status = 'Assigned',
                   updated_at = ?, dispatch_note = ? WHERE report_id = ? AND status = 'Pending'""",
                (handler["handler_id"], now_iso(), "Assigned to least-loaded eligible handler.", report["report_id"]),
            )
            conn.execute(
                """INSERT INTO status_history
                   (report_id, old_status, new_status, changed_by, changed_at, note)
                   VALUES (?, 'Pending', 'Assigned', 'SYSTEM', ?, ?)""",
                (report["report_id"], now_iso(), f"Assigned to {handler['handler_id']}"),
            )
            decisions.append({"report_id": report["report_id"], "status": "Assigned", "handler_id": handler["handler_id"]})
        else:
            note = "No eligible handler; report remains in waiting queue."
            conn.execute(
                "UPDATE reports SET dispatch_note = ?, updated_at = ? WHERE report_id = ?",
                (note, now_iso(), report["report_id"]),
            )
            decisions.append({"report_id": report["report_id"], "status": "Pending", "handler_id": None})
    return decisions


@app.get("/api/health")
def health():
    return jsonify({"ok": True, "service": "Metro Anomaly Reporter API"})


@app.post("/api/reports")
def create_report():
    data = request.get_json(silent=True) or {}
    reporter = str(data.get("reporter_name", "")).strip()
    station = str(data.get("station_code", "")).strip()
    anomaly = str(data.get("anomaly_code", "")).strip()
    description = str(data.get("description", "")).strip()

    if not reporter or not description:
        return jsonify({"error": "Reporter name and description are required."}), 400

    validation = validate_identifiers(station, anomaly)
    if not validation["valid"]:
        return jsonify({"error": "Identifier validation failed.", "validation": validation}), 400

    classification = classify_report(anomaly, description)
    if not classification["ok"]:
        return jsonify({"error": classification["message"], "validation": validation}), 400

    route = route_report(station, classification["category"])
    report_id = generate_report_id()
    created = now_iso()
    initial_status = "Pending"

    with get_connection() as conn:
        conn.execute(
            """INSERT INTO reports
            (report_id, reporter_name, station_code, anomaly_code, description,
             category, priority, zone, destination, handler_id, status,
             created_at, updated_at, validation_json, dispatch_note)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?, ?, ?, ?, ?)""",
            (
                report_id, reporter, station, anomaly, description,
                classification["category"], classification["priority"],
                route["zone"], route["destination"], initial_status,
                created, created, json.dumps(validation), "Awaiting dispatch.",
            ),
        )
        conn.execute(
            """INSERT INTO status_history
            (report_id, old_status, new_status, changed_by, changed_at, note)
            VALUES (?, NULL, 'Pending', ?, ?, ?)""",
            (report_id, reporter, created, "Report submitted and validated."),
        )
        dispatch_result = dispatch_pending_reports(conn)
        saved = dict(conn.execute(
            "SELECT * FROM reports WHERE report_id = ?", (report_id,)
        ).fetchone())

    return jsonify({
        "report": saved,
        "validation": validation,
        "classification": classification,
        "routing": route,
        "dispatch_queue_result": dispatch_result,
    }), 201


@app.get("/api/reports")
def list_reports():
    with get_connection() as conn:
        rows = conn.execute("SELECT * FROM reports ORDER BY created_at DESC").fetchall()
    return jsonify([dict(row) for row in rows])


@app.get("/api/reports/<report_id>")
def get_report(report_id):
    with get_connection() as conn:
        row = conn.execute("SELECT * FROM reports WHERE report_id = ?", (report_id,)).fetchone()
        if not row:
            return jsonify({"error": "Report not found."}), 404
        history = conn.execute(
            "SELECT old_status, new_status, changed_by, changed_at, note FROM status_history WHERE report_id = ? ORDER BY id",
            (report_id,),
        ).fetchall()
    result = dict(row)
    result["history"] = [dict(item) for item in history]
    return jsonify(result)


@app.get("/api/handlers")
def list_handlers():
    with get_connection() as conn:
        rows = conn.execute("SELECT * FROM handlers ORDER BY zone, handler_id").fetchall()
    return jsonify([dict(row) for row in rows])


@app.put("/api/handlers/<handler_id>")
def update_handler(handler_id):
    data = request.get_json(silent=True) or {}
    with get_connection() as conn:
        handler = conn.execute("SELECT * FROM handlers WHERE handler_id = ?", (handler_id,)).fetchone()
        if not handler:
            return jsonify({"error": "Handler not found."}), 404

        available = data.get("available", handler["available"])
        capacity = data.get("capacity", handler["capacity"])
        if not isinstance(available, (bool, int)) or int(capacity) < 0:
            return jsonify({"error": "Invalid availability or capacity."}), 400

        conn.execute(
            "UPDATE handlers SET available = ?, capacity = ? WHERE handler_id = ?",
            (int(bool(available)), int(capacity), handler_id),
        )
        result = dict(conn.execute("SELECT * FROM handlers WHERE handler_id = ?", (handler_id,)).fetchone())
    return jsonify(result)


@app.put("/api/reports/<report_id>/status")
def update_status(report_id):
    data = request.get_json(silent=True) or {}
    new_status = data.get("status")
    changed_by = str(data.get("changed_by", "Handler")).strip() or "Handler"
    note = str(data.get("note", "")).strip()

    if new_status not in VALID_STATUSES:
        return jsonify({"error": "Status must be Pending, Assigned, In Progress, or Resolved."}), 400

    with get_connection() as conn:
        report = conn.execute("SELECT * FROM reports WHERE report_id = ?", (report_id,)).fetchone()
        if not report:
            return jsonify({"error": "Report not found."}), 404

        old_status = report["status"]
        if old_status == "Resolved" and new_status != "Resolved":
            return jsonify({"error": "Resolved reports cannot be reopened in this demo."}), 400

        conn.execute(
            "UPDATE reports SET status = ?, updated_at = ? WHERE report_id = ?",
            (new_status, now_iso(), report_id),
        )
        conn.execute(
            """INSERT INTO status_history
            (report_id, old_status, new_status, changed_by, changed_at, note)
            VALUES (?, ?, ?, ?, ?, ?)""",
            (report_id, old_status, new_status, changed_by, now_iso(), note),
        )

        # Release handler capacity when report is resolved.
        if new_status == "Resolved" and old_status != "Resolved" and report["handler_id"]:
            conn.execute(
                """UPDATE handlers SET current_workload =
                   CASE WHEN current_workload > 0 THEN current_workload - 1 ELSE 0 END
                   WHERE handler_id = ?""",
                (report["handler_id"],),
            )
        result = dict(conn.execute("SELECT * FROM reports WHERE report_id = ?", (report_id,)).fetchone())
    return jsonify(result)


@app.post("/api/dispatch")
def run_dispatch():
    with get_connection() as conn:
        decisions = dispatch_pending_reports(conn)
    return jsonify({"decisions": decisions})


@app.get("/api/routing")
def routing_info():
    return jsonify({
        "routes": [
            {"prefix": "EA", "zone": "East", "destination": "East Control Room"},
            {"prefix": "WE", "zone": "West", "destination": "West Control Room"},
            {"prefix": "CE", "zone": "Central", "destination": "Central Control Room"},
        ],
        "medical_override": "Central Emergency Line",
        "unknown_prefix": "Central Fallback / Correction Queue",
    })


@app.get("/api/analytics")
def analytics():
    with get_connection() as conn:
        total = conn.execute("SELECT COUNT(*) FROM reports").fetchone()[0]
        by_status = conn.execute("SELECT status, COUNT(*) AS count FROM reports GROUP BY status").fetchall()
        by_zone = conn.execute("SELECT zone, COUNT(*) AS count FROM reports GROUP BY zone").fetchall()
        by_category = conn.execute("SELECT category, COUNT(*) AS count FROM reports GROUP BY category").fetchall()
    return jsonify({
        "total": total,
        "by_status": {r["status"]: r["count"] for r in by_status},
        "by_zone": {r["zone"]: r["count"] for r in by_zone},
        "by_category": {r["category"]: r["count"] for r in by_category},
    })


if __name__ == "__main__":
    app.run(debug=True, port=5000)
