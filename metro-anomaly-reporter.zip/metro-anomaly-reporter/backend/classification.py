ANOMALY_CODE_CATEGORY = {
    "A01": "Safety",
    "A02": "Technical",
    "A03": "Crowd",
    "A04": "Cleanliness",
    "A05": "Medical",
}

# Fixed precedence makes conflicting keyword matches deterministic.
KEYWORD_RULES = [
    ("Medical", ("unconscious", "injury", "injured", "medical", "bleeding", "collapsed")),
    ("Safety", ("fire", "smoke", "danger", "suspicious", "hazard")),
    ("Technical", ("lift", "elevator", "escalator", "signal", "equipment", "machine", "breakdown")),
    ("Crowd", ("overcrowd", "crowd", "congestion", "rush", "queue")),
    ("Cleanliness", ("garbage", "dirty", "spill", "cleaning", "waste", "litter")),
]

PRIORITY = {
    "Medical": "Critical",
    "Safety": "Critical",
    "Technical": "High",
    "Crowd": "High",
    "Cleanliness": "Normal",
}


def classify_report(anomaly_code: str, description: str) -> dict:
    code_category = ANOMALY_CODE_CATEGORY.get(anomaly_code)
    if not code_category:
        return {
            "ok": False,
            "category": None,
            "priority": None,
            "message": f"Anomaly code {anomaly_code!r} is not mapped. Use A01-A05 or ask an administrator to map it.",
        }

    text = (description or "").lower()
    keyword_matches = [
        category
        for category, keywords in KEYWORD_RULES
        if any(keyword in text for keyword in keywords)
    ]

    # If description contains known category signals, apply documented precedence.
    # Otherwise use the configured anomaly-code mapping.
    category = keyword_matches[0] if keyword_matches else code_category
    return {
        "ok": True,
        "category": category,
        "priority": PRIORITY[category],
        "code_category": code_category,
        "keyword_matches": keyword_matches,
        "classification_note": (
            f"Description matched multiple/specific rules; precedence selected {category}."
            if keyword_matches and category != code_category
            else f"Category selected from anomaly code {anomaly_code}."
        ),
    }
