const BASE = "http://127.0.0.1:5000/api";

async function request(path, options = {}) {
  const response = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options,
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Request failed");
  return data;
}

export const api = {
  submit: (body) => request("/reports", { method: "POST", body: JSON.stringify(body) }),
  reports: () => request("/reports"),
  report: (id) => request(`/reports/${encodeURIComponent(id)}`),
  handlers: () => request("/handlers"),
  updateStatus: (id, status) => request(`/reports/${encodeURIComponent(id)}/status`, {
    method: "PUT", body: JSON.stringify({ status, changed_by: "Dashboard User" }),
  }),
  updateHandler: (id, body) => request(`/handlers/${encodeURIComponent(id)}`, {
    method: "PUT", body: JSON.stringify(body),
  }),
  analytics: () => request("/analytics"),
  routing: () => request("/routing"),
  dispatch: () => request("/dispatch", { method: "POST", body: "{}" }),
};
