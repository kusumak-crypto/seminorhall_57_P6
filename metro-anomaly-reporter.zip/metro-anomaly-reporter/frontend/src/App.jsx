import React, { useEffect, useState } from "react";
import { api } from "./api";

const emptyForm = {
  reporter_name: "", station_code: "", anomaly_code: "A02",
  description: "", urgency: "High"
};

function App() {
  const [page, setPage] = useState("submit");
  const [form, setForm] = useState(emptyForm);
  const [reports, setReports] = useState([]);
  const [handlers, setHandlers] = useState([]);
  const [analytics, setAnalytics] = useState(null);
  const [searchId, setSearchId] = useState("");
  const [searched, setSearched] = useState(null);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function refresh() {
    try {
      const [r, h, a] = await Promise.all([api.reports(), api.handlers(), api.analytics()]);
      setReports(r); setHandlers(h); setAnalytics(a);
    } catch (e) { setError(e.message); }
  }
  useEffect(() => { refresh(); }, []);

  function change(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function submit(e) {
    e.preventDefault(); setBusy(true); setError(""); setMessage("");
    try {
      const result = await api.submit(form);
      setMessage(`Report ${result.report.report_id} submitted. Category: ${result.report.category}. Destination: ${result.report.destination}. Status: ${result.report.status}.`);
      setForm(emptyForm); await refresh();
    } catch (e) { setError(e.message); }
    finally { setBusy(false); }
  }

  async function search() {
    setError(""); setSearched(null);
    if (!searchId.trim()) return;
    try { setSearched(await api.report(searchId.trim())); }
    catch (e) { setError(e.message); }
  }

  async function setStatus(id, status) {
    setError("");
    try { await api.updateStatus(id, status); await refresh(); }
    catch (e) { setError(e.message); }
  }

  async function toggleHandler(h) {
    setError("");
    try {
      await api.updateHandler(h.handler_id, { available: !Boolean(h.available) });
      await refresh();
    } catch (e) { setError(e.message); }
  }

  async function dispatch() {
    setError(""); setMessage("");
    try {
      const result = await api.dispatch();
      setMessage(`Dispatch run completed. Decisions: ${result.decisions.length}`);
      await refresh();
    } catch (e) { setError(e.message); }
  }

  const nav = [
    ["submit", "Submit report"], ["user", "User dashboard"],
    ["handler", "Handler dashboard"], ["routing", "Routing"], ["analytics", "Analytics"]
  ];

  return <div className="app-shell">
    <header className="topbar">
      <div><div className="eyebrow">METRO OPERATIONS</div><h1>Station Anomaly Reporter</h1></div>
      <span className="live"><i /> System prototype</span>
    </header>

    <nav className="nav">
      {nav.map(([key, label]) => <button key={key} className={page === key ? "active" : ""} onClick={() => {setPage(key);setError("");setMessage("");}}>{label}</button>)}
    </nav>

    <main>
      {error && <div className="alert error">{error}</div>}
      {message && <div className="alert success">{message}</div>}

      {page === "submit" && <section className="panel narrow">
        <div className="section-heading"><div><div className="eyebrow">NEW INCIDENT</div><h2>Submit an anomaly report</h2><p>Enter the station and anomaly details. Identifiers are checked by DFA and Regex in the backend.</p></div></div>
        <form onSubmit={submit} className="form-grid">
          <label>Reporter name<input name="reporter_name" value={form.reporter_name} onChange={change} required placeholder="Enter staff name" /></label>
          <label>Station code<input name="station_code" value={form.station_code} onChange={change} required placeholder="Example: EA123" maxLength="5" /></label>
          <label>Anomaly code<select name="anomaly_code" value={form.anomaly_code} onChange={change}><option>A01</option><option>A02</option><option>A03</option><option>A04</option><option>A05</option></select></label>
          <label>Urgency<select name="urgency" value={form.urgency} onChange={change}><option>Normal</option><option>High</option><option>Critical</option></select></label>
          <label className="full">Description<textarea name="description" value={form.description} onChange={change} required rows="4" placeholder="Describe what happened..." /></label>
          <div className="full hint">Demo code mapping: A01 Safety · A02 Technical · A03 Crowd · A04 Cleanliness · A05 Medical. The backend applies its documented category and priority rules.</div>
          <button className="primary full" disabled={busy}>{busy ? "Submitting..." : "Submit report"}</button>
        </form>
      </section>}

      {page === "user" && <section className="panel">
        <div className="section-heading"><div><div className="eyebrow">OVERVIEW</div><h2>User dashboard</h2><p>Search for a report and track its current status.</p></div></div>
        <Stats analytics={analytics} />
        <div className="search-row"><input value={searchId} onChange={e=>setSearchId(e.target.value)} placeholder="Enter report ID, e.g. MAR-..." /><button className="primary" onClick={search}>Search report</button></div>
        {searched && <div className="detail-card"><h3>{searched.report_id}</h3><p>{searched.description}</p><p><b>Category:</b> {searched.category} · <b>Priority:</b> {searched.priority}</p><p><b>Destination:</b> {searched.destination} · <b>Handler:</b> {searched.handler_id || "Waiting queue"}</p><p><b>Status:</b> <Status value={searched.status}/></p>{searched.history?.map((h,i)=><small key={i}>{h.changed_at} — {h.old_status || "Created"} → {h.new_status} ({h.changed_by})<br/></small>)}</div>}
        <ReportTable reports={reports} />
      </section>}

      {page === "handler" && <section className="panel">
        <div className="section-heading"><div><div className="eyebrow">OPERATIONS TEAM</div><h2>Handler dashboard</h2><p>View assigned work and update report status or availability.</p></div></div>
        <h3>Handlers</h3>
        <div className="table-wrap"><table><thead><tr><th>ID</th><th>Name</th><th>Zone</th><th>Workload</th><th>Availability</th><th>Action</th></tr></thead><tbody>
          {handlers.map(h=><tr key={h.handler_id}><td>{h.handler_id}</td><td>{h.name}</td><td>{h.zone}</td><td>{h.current_workload}/{h.capacity}</td><td>{h.available ? "Available" : "Unavailable"}</td><td><button className="small" onClick={()=>toggleHandler(h)}>Toggle availability</button></td></tr>)}
        </tbody></table></div>
        <h3 className="spaced">Assigned reports</h3>
        <ReportTable reports={reports.filter(r=>r.handler_id)} onStatus={setStatus} />
      </section>}

      {page === "routing" && <section className="panel">
        <div className="section-heading"><div><div className="eyebrow">DISPATCH CONTROL</div><h2>Routing management</h2><p>Station-prefix lookup, emergency override and dispatch queue.</p></div><button className="primary" onClick={dispatch}>Process pending queue</button></div>
        <div className="route-grid">
          <div className="route-card"><b>EA</b><span>East Control Room</span></div>
          <div className="route-card"><b>WE</b><span>West Control Room</span></div>
          <div className="route-card"><b>CE</b><span>Central Control Room</span></div>
          <div className="route-card emergency"><b>Medical</b><span>Central Emergency Line</span></div>
        </div>
        <h3 className="spaced">Pending / fallback reports</h3>
        <ReportTable reports={reports.filter(r=>r.status==="Pending")} />
        <h3 className="spaced">Handler loads</h3>
        <div className="table-wrap"><table><thead><tr><th>Handler</th><th>Zone</th><th>Load</th><th>Available</th></tr></thead><tbody>{handlers.map(h=><tr key={h.handler_id}><td>{h.handler_id} — {h.name}</td><td>{h.zone}</td><td>{h.current_workload}/{h.capacity}</td><td>{h.available ? "Yes" : "No"}</td></tr>)}</tbody></table></div>
      </section>}

      {page === "analytics" && <section className="panel">
        <div className="section-heading"><div><div className="eyebrow">REPORT INSIGHTS</div><h2>Analytics dashboard</h2><p>Live counts from the SQLite database.</p></div></div>
        <Stats analytics={analytics} />
        <div className="analytics-grid">
          <Breakdown title="By status" data={analytics?.by_status}/>
          <Breakdown title="By zone" data={analytics?.by_zone}/>
          <Breakdown title="By category" data={analytics?.by_category}/>
        </div>
      </section>}
    </main>
    <footer>Metro Station Anomaly Reporter · Hackathon prototype · Demo data must be verified before real deployment.</footer>
  </div>;
}

function Stats({analytics}) {
  const statuses = analytics?.by_status || {};
  return <div className="stats">
    <Stat label="Total reports" value={analytics?.total ?? 0}/>
    <Stat label="Pending" value={statuses.Pending ?? 0}/>
    <Stat label="Assigned" value={statuses.Assigned ?? 0}/>
    <Stat label="Resolved" value={statuses.Resolved ?? 0}/>
  </div>;
}
function Stat({label,value}) { return <div className="stat"><span>{label}</span><b>{value}</b></div>; }
function Status({value}) { return <span className={`status ${String(value).toLowerCase().replaceAll(" ","-")}`}>{value}</span>; }
function ReportTable({reports,onStatus}) {
  if (!reports.length) return <p className="empty">No reports to display yet.</p>;
  return <div className="table-wrap"><table><thead><tr><th>Report ID</th><th>Station</th><th>Category</th><th>Priority</th><th>Destination</th><th>Handler</th><th>Status</th>{onStatus && <th>Update</th>}</tr></thead><tbody>
    {reports.map(r=><tr key={r.report_id}><td>{r.report_id}</td><td>{r.station_code}</td><td>{r.category}</td><td>{r.priority}</td><td>{r.destination}</td><td>{r.handler_id || "Queue"}</td><td><Status value={r.status}/></td>{onStatus && <td><select value={r.status} onChange={e=>onStatus(r.report_id,e.target.value)}><option>Assigned</option><option>In Progress</option><option>Resolved</option></select></td>}</tr>)}
  </tbody></table></div>;
}
function Breakdown({title,data}) {
  const entries = Object.entries(data || {});
  const max = Math.max(1, ...entries.map(([,v])=>v));
  return <div className="breakdown"><h3>{title}</h3>{entries.length ? entries.map(([key,value])=><div className="bar-row" key={key}><div><span>{key}</span><b>{value}</b></div><div className="bar"><i style={{width:`${value/max*100}%`}}/></div></div>) : <p className="empty">No data yet.</p>}</div>;
}

export default App;
