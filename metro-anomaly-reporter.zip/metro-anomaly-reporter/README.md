# Metro Station Anomaly Reporter

Starter implementation for the P6 hackathon problem.

## Stack
- React + Vite frontend
- Python Flask backend
- SQLite database
- DFA + equivalent regular-expression validation
- Rule-based five-category classification
- Prefix-based corridor routing
- Priority-ordered dispatch queue
- Greedy least-loaded eligible handler assignment

> The assignment sheet mentions both MERN and Flask + SQLite. This implementation follows the more specific Flask + SQLite integration requirement. Confirm the allowed stack with your mentor.

## Demo assumptions (replace with organizer-approved mappings)
- Station prefixes: EA = East, WE = West, CE = Central.
- Anomaly codes: A01 Safety, A02 Technical, A03 Crowd, A04 Cleanliness, A05 Medical.
- Priority: Medical = Critical; Safety = Critical; Technical/Crowd = High; Cleanliness = Normal.
- Classification precedence for conflicting description keywords: Medical > Safety > Technical > Crowd > Cleanliness.
- Medical reports always route to the Central Emergency Line.

## Run backend
```bash
cd backend
python -m venv .venv
# Windows PowerShell:
.venv\Scripts\Activate.ps1
# macOS/Linux:
# source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Backend: http://127.0.0.1:5000

## Run frontend (new terminal)
```bash
cd frontend
npm install
npm run dev
```
Frontend: http://localhost:5173

## Run tests
```bash
cd backend
python -m unittest discover -s tests -v
```

The SQLite database (`metro.db`) is created automatically on first backend start.
